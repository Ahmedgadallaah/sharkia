<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url ('/admin/countryside/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>





 <div class="box box-info">
    <div class="box-header">
      <h3 class="box-title"><?php echo e(trans('message.description')); ?> (EN)</h3>
      <!-- tools box -->
      <div class="pull-right box-tools">
        <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>

      </div>
      <!-- /. tools -->
    </div>
    <!-- /.box-header -->
    <div class="box-body pad">

            <textarea   class="form-control  description<?php echo e($errors->has('en_description') ? 'is-invalid' : ''); ?>" id="description" name="en_description" rows="10" cols="80" value="<?php echo e(old('en_description', '')); ?>" required></textarea>
            <?php if($errors->has('en_description')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('en_description')); ?>

            </div>
        <?php endif; ?>
    </div>

</div>


<div class="box box-info">
    <div class="box-header">
      <h3 class="box-title"><?php echo e(trans('message.description')); ?> (ar)</h3>
      <!-- tools box -->
      <div class="pull-right box-tools">
        <button type="button" class="btn btn-info btn-sm" data-widget="collapse" data-toggle="tooltip"
                title="Collapse">
          <i class="fa fa-minus"></i></button>

      </div>
      <!-- /. tools -->
    </div>
    <!-- /.box-header -->
    <div class="box-body pad">

            <textarea   class="form-control description <?php echo e($errors->has('ar_description') ? 'is-invalid' : ''); ?>"  id="description" name="ar_description" rows="10" cols="80" value="<?php echo e(old('ar_description', '')); ?>" required></textarea>
            <?php if($errors->has('ar_description')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('ar_description')); ?>

            </div>
        <?php endif; ?>
    </div>

</div>

<button type="submit" class="btn btn-primary">submit</button>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sharkia\resources\views/admin/countrysides/create.blade.php ENDPATH**/ ?>