<?php $__env->startSection('content'); ?>

<form action="<?php echo e(url ('/admin/body/store')); ?>" method="post" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>


<div class="card-body" id="english-form">
    <div class="form-group">
        <label class="required" for="en_name"><?php echo e(trans('message.name')); ?> (EN)</label>
        <input class="form-control <?php echo e($errors->has('en_name') ? 'is-invalid' : ''); ?>" type="text" name="en_name" id="en_name" value="<?php echo e(old('en_name', '')); ?>" required>
        <?php if($errors->has('en_name')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('en_name')); ?>

            </div>
        <?php endif; ?>

    </div>
</div>

 <div class="card-body" id="arabic-form">
    <div class="form-group">
        <label class="required" for="ar_name"><?php echo e(trans('message.name')); ?> (Ar)</label>
        <input class="form-control <?php echo e($errors->has('ar_name') ? 'is-invalid' : ''); ?>" type="text" name="ar_name" id="ar_name" value="<?php echo e(old('ar_name', '')); ?>" required>
        <?php if($errors->has('ar_name')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('ar_name')); ?>

            </div>
        <?php endif; ?>

    </div>
 </div>





 <div class="card-body" id="arabic-form">
    <div class="form-group">
        <label class="required" for="image"><?php echo e(trans('message.image')); ?></label>
            <input  type="file" class="form-control <?php echo e($errors->has('image') ? 'is-invalid' : ''); ?>"  name="image" accept="image/*" required>
        <?php if($errors->has('image')): ?>
            <div class="invalid-feedback">
                <?php echo e($errors->first('image')); ?>

            </div>
        <?php endif; ?>
    </div>
 </div>

<button type="submit" class="btn btn-primary">submit</button>

</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sharkia\resources\views/admin/bodies/create.blade.php ENDPATH**/ ?>