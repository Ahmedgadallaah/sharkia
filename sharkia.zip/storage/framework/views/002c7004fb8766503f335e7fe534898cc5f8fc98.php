<?php $__env->startSection('content'); ?>

<div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
                <a href="<?php echo e(url ('/admin/antique/create')); ?>"><button  class="btn btn-primary"><?php echo e(trans('message.Add New')); ?></button></a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>Id</th>
                  <th><?php echo e(trans('message.name')); ?> </th>

                  <th><?php echo e(trans('message.image')); ?></th>

                  <th colspan="2"> Action</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $antiques; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $antique): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($antique->id); ?></td>
                  <td><?php echo e($antique->name); ?></td>


                  <td><img src="<?php echo e(asset('images/antique/'.$antique->image)); ?>" style='width:60px;height:60px;'></td>
                   <td>

                  <a id="delete" class="btn btn-primary" href="<?php echo e(URL::to('/admin/antique/edit/'.$antique->id)); ?> ">
								<i class="halflings-icon white trash"></i>
                            Edit</a>
                            <a id="delete" class="btn btn-danger" href="<?php echo e(URL::to('admin/antique/delete/'.$antique->id)); ?> ">
								<i class="halflings-icon white trash"></i>
                            x</a>
                        </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <span><?php echo e($antiques->links()); ?></span>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\sharkia\resources\views/admin/antiques/index.blade.php ENDPATH**/ ?>