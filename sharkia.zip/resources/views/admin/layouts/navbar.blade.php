<header class="main-header">
    <!-- Logo -->
    <a href="{{ URL::to('admin') }}" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>Delta</b>Deals</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Delta Deals</b></span>
    </a>



    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
    <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Sidebar toggle button-->


<div class="dropdown">
           <button class="btn btn-default dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">  </button>
          <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    @guest

                            <a class="dropdown-item" href="{{ route('login') }}">{{ __('Login') }}</a>

                        @if (Route::has('register'))

                                <a class="dropdown-item" href="{{ route('register') }}">{{ __('Register') }}</a>

                        @endif
                    @else
                                <a class="dropdown-item" href="{{ route('logout') }}"
                                   onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                                <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>


                        @endguest


                        @if ( Config::get('app.locale') == 'en')
                        <a class="dropdown-item" href="{{ url('lang/ar') }}">AR</a>
                    @elseif ( Config::get('app.locale') == 'ar' )
                        <a class="dropdown-item" href="{{ url('lang/en') }}">الإنجليزية</a>
                    @endif

        </div>
</div>

      @include('admin.layouts.menu')
    </nav>

  </header>

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="{{url('/')}}/design/adminlte/dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p></p>
          <a href="#"><i class="fa fa-circle text-success"></i> {{ trans('message.online') }}</a>
        </div>

      </div>


      <!-- search form -->

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">

        <li class="header">{{ trans('message.dashboard') }}</li>


        <li class="treeview">
            <a href="#">
              <span>{{trans('message.governorate leaders')}}</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">

                {{-- <ul class="treeview-menu">
                  <li><a href="#"><i class="fa fa-circle-o"></i> Level Two</a></li>
                  <li class="treeview">
                    <a href="#"><i class="fa fa-circle-o"></i> Level Two
                      <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                      </span>
                    </a>
                    <ul class="treeview-menu">
                      <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                      <li><a href="#"><i class="fa fa-circle-o"></i> Level Three</a></li>
                    </ul>
                  </li>
                </ul> --}}

              <li><a href="{{url::to('admin/employee')}}"><i class="fa fa-circle-o"></i> {{trans('message.governorate leaders')}}</a></li>
              <li><a href="{{url::to('admin/governer')}}"><i class="fa fa-circle-o"></i> {{trans('message.Former governors')}}</a></li>
            </ul>
        </li>

        <li class="treeview">
            <a href="#">
              <span>{{trans('message.governorate Entities')}}</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li><a href="{{url::to('admin/city')}}"><i class="fa fa-circle-o"></i> {{trans('message.centers and cities')}}</a></li>
              <li><a href="{{url::to('admin/body')}}"><i class="fa fa-circle-o"></i> {{trans('message.bodies')}}</a></li>
              <li><a href="{{url::to('admin/directorate')}}"><i class="fa fa-circle-o"></i> {{trans('message.directorates')}}</a></li>
              <li><a href="{{url::to('admin/company')}}"><i class="fa fa-circle-o"></i> {{trans('message.companies')}}</a></li>
            </ul>
        </li>







          <li class="treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.settings') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li ><a href="{{url ('/admin/setting') }}"><i class="fa fa-circle-o"></i> {{ trans('message.settings') }}</a></li>

          </ul>
        </li>



        <li class=" treeview">
            <a href="">
              <i class="fa fa-dashboard"></i> <span>{{ trans('message.about') }}</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li class=""><a href="{{url ('/admin/about') }}"><i class="fa fa-circle-o"></i> {{ trans('message.about') }}</a></li>

            </ul>
          </li>




        <li class="treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.categories') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="{{url ('/admin/category') }}"><i class="fa fa-circle-o"></i> {{ trans('message.categories') }}</a></li>
          </ul>
        </li>



        <li class="treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.products') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="{{url ('/admin/product') }}"><i class="fa fa-circle-o"></i> {{ trans('message.products') }}</a></li>
          </ul>
        </li>



        <li class="treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.partners') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class=" treeview-menu">
            <li class=""><a href="{{url ('/admin/partner') }}"><i class="fa fa-circle-o"></i> {{ trans('message.partners') }}</a></li>
          </ul>
        </li>


        <li class="treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.social') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li ><a href="{{url ('/admin/slink') }}"><i class="fa fa-circle-o"></i> {{ trans('message.social') }}</a></li>
          </ul>
        </li>
        {{-- {{'/admin/social' == request()->path() ? 'active':'' || 'admin/social/create' == request()->path() ? 'active':'' }} --}}
        <li class=" treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.slider') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            {{-- class="{{'/admin/social' == request()->path() ? 'active':''}} --}}
            {{-- class="{{'/admin/social/create' == request()->path() ? 'active':''}}" --}}
            <li ><a href="{{url ('/admin/slider') }}"><i class="fa fa-circle-o"></i> {{ trans('message.slider') }}</a></li>

          </ul>
        </li>
        <li class=" treeview">
          <a href="">
            <i class="fa fa-dashboard"></i> <span>{{ trans('message.contacts') }}</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li class=""><a href="{{url ('/admin/contact') }}"><i class="fa fa-circle-o"></i> {{ trans('message.contacts') }}</a></li>

          </ul>
        </li>


        <li class=" treeview">
            <a href="">
              <i class="fa fa-dashboard"></i> <span>{{ trans('message.contact info') }}</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li class=""><a href="{{url ('/admin/info') }}"><i class="fa fa-circle-o"></i> {{ trans('message.contact info') }}</a></li>

            </ul>
          </li>


          <li class=" treeview">
            <a href="">
              <i class="fa fa-dashboard"></i> <span>{{ trans('message.season') }}</span>
              <span class="pull-right-container">
                <i class="fa fa-angle-left pull-right"></i>
              </span>
            </a>
            <ul class="treeview-menu">
              <li class=""><a href="{{url ('/admin/season') }}"><i class="fa fa-circle-o"></i> {{ trans('message.season') }}</a></li>

            </ul>
          </li>



      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>
