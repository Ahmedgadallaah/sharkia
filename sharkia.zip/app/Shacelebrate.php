<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shacelebrate extends Model
{
    protected $fillable = ['image'];
}
