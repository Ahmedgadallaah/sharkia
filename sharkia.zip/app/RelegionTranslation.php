<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RelegionTranslation extends Model
{
    public $timestamps = false;
    protected $fillable = ['description'];
}
