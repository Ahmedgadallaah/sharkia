<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class InvestChance extends Model
{

    protected $fillable = ['pdf'];


}
