<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvestMap extends Model
{
    protected $fillable = ['pdf'];

}
