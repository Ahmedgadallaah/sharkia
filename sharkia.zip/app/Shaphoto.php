<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shaphoto extends Model
{


    protected $fillable = ['id','image'];

}
